package com.api.atos.apiSpringAngularSuivicombdd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiSpringAngularSuivicombddApplicationTests {

	@Test
	void contextLoads() {
	}

}
